#include "timerA.h"
#include "LED.h"
#define TA0CCR0_VALUE (62500-1)
extern int LED;

void ConfigureTimerA(void)
{
    TA0CTL = (MC_0 | TACLR); //Stop the timer and clear it
    TA0CTL = (TASSEL_2 | ID_2 | MC_1); //Choose SMCLK select and input divider and start it in up mode
    TA0CCR0 = TA0CCR0_VALUE; //CCRO = period * freq * divider (1/8)
//Enable interrupt
    TA0CCTL0 |= CCIE;
}

#pragma vector = TIMER0_A0_VECTOR
// Timer a interrupt service routine
__interrupt void TimerA0_routine(void)
{
    if(LED == 1){
        TOGGLE_LED1;
    }
    else if(LED == 0){
        TOGGLE_LED2;
    }

//ISR Code to toggle RED Led
}
