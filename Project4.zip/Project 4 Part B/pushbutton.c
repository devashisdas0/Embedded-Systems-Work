#include "pushbutton.h"
#include "LED.h"
#define BUTTON BIT3

extern int LED;

void InitializePushButtonPortPin (void)
{
    P1DIR &= ~BUTTON; //Enables input
    P1OUT |= BUTTON; //Enables output
    P1REN  |= BUTTON;//Enables pull up resistor
    P1IE |= BUTTON; //Enables interrupt
    P1IES |= BUTTON; // Enables Interrupt Service for active low

    LED = 1;
}

#pragma vector = PORT1_VECTOR
// Button interrupt service routine
__interrupt void Button_routine(void)
{
    LED = 1 - LED;

    TURN_OFF_LED1;
    TURN_OFF_LED2;

    P1IFG &= ~BUTTON;


    
}
