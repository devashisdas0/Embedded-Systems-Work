#ifndef PUSHBUTTON_H
#define PUSHBUTTON_H

#include <msp430.h>
int LED;
// Prototypes
void InitializePushButtonPortPin(void);

#endif
